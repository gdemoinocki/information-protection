﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inf_p_lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            try
            {
                string plaintext = PlaintextTextBox.Text;
                string encryptionKey = EncryptionKeyTextBox.Text;

                if (string.IsNullOrEmpty(plaintext) || string.IsNullOrEmpty(encryptionKey))
                {
                    MessageBox.Show("Пожалуйста, введите текст и ключ для шифрования.", "Ошибка");
                    return;
                }

                byte[] encryptedData = AESEncrypt(Encoding.UTF8.GetBytes(plaintext), Encoding.UTF8.GetBytes(encryptionKey));
                // Преобразование зашифрованных данных в строку в формате Base64
                CiphertextTextBox.Text = Convert.ToBase64String(encryptedData);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка шифрования: " + ex.Message, "Ошибка");
            }
        }

        private void DecryptButton_Click(object sender, EventArgs e)
        {
            try
            {
                string ciphertext = CiphertextTextBox.Text;
                string decryptionKey = DecryptionKeyTextBox.Text;

                if (string.IsNullOrEmpty(ciphertext) || string.IsNullOrEmpty(decryptionKey))
                {
                    MessageBox.Show("Пожалуйста, введите зашифрованный текст и ключ для дешифрования.", "Ошибка");
                    return;
                }

                byte[] ciphertextBytes = Convert.FromBase64String(ciphertext);
                byte[] decryptedData = AESDecrypt(ciphertextBytes, Encoding.UTF8.GetBytes(decryptionKey));
                DecryptedTextBox.Text = Encoding.UTF8.GetString(decryptedData);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка дешифрования: " + ex.Message, "Ошибка");
            }
        }
        // Метод для корректировки длины ключа до требуемой длины
        private byte[] AdjustKey(byte[] key, int requiredLength)
        {
            // Если ключ короче требуемой длины, дополняем его нулями
            if (key.Length < requiredLength)
            {
                byte[] adjustedKey = new byte[requiredLength];
                Array.Copy(key, adjustedKey, key.Length);
                return adjustedKey;
            }
            // Если ключ длиннее, обрезаем его
            else if (key.Length > requiredLength)
            {
                byte[] adjustedKey = new byte[requiredLength];
                Array.Copy(key, adjustedKey, requiredLength);
                return adjustedKey;
            }
            // Если ключ уже нужной длины, возвращаем его
            return key;
        }

        private byte[] AESEncrypt(byte[] data, byte[] key)
        {
            // Приводим ключ к нужной длине (16, 24 или 32 байта)
            byte[] adjustedKey = AdjustKey(key, 16); // Используем 16 байт для AES-128
                                                     // Создаем массив для зашифрованных данных
            byte[] encryptedData = new byte[data.Length];
            // Шифрование данных с использованием операции XOR с ключом
            for (int i = 0; i < data.Length; i++)
            {
                encryptedData[i] = (byte)(data[i] ^ adjustedKey[i % adjustedKey.Length]); // (A ^ B) ^ B = A ; A — исходные данные. B — ключ.
            }
            return encryptedData;
        }

        private byte[] AESDecrypt(byte[] data, byte[] key)
        {
            // Приводим ключ к нужной длине (16, 24 или 32 байта)
            byte[] adjustedKey = AdjustKey(key, 16); // Используем 16 байт для AES-128
            // Создаем массив для расшифрованных данных
            byte[] decryptedData = new byte[data.Length];
            // Дешифрование данных с использованием операции XOR с ключом
            for (int i = 0; i < data.Length; i++)
            {
                decryptedData[i] = (byte)(data[i] ^ adjustedKey[i % adjustedKey.Length]); // Простое XOR с ключом
            }
            return decryptedData;
        }
    }
}
