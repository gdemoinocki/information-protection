﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inf_p_lab1
{
    public partial class Form1 : Form
    {
        private const string NormalAlphabet = "абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
        private string EncryptedAlphabet =    "ющгътцфэчхяпжкзвыбьйдаштмуоеинлрёЫЮШЯГЗЪЦФЭХЧБПЙЖЬВДМКАОЛТЕРУСНИЁЩ"; 
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void encryptButton_Click(object sender, EventArgs e)
        {
            inputText.Text = Encrypt(inputTextBox.Text);
        }

        private void decryptButton_Click(object sender, EventArgs e)
        {
            outputText.Text = Decrypt(inputTextBox.Text);
        }

        private string Encrypt(string text)
        {
            StringBuilder encryptedText = new StringBuilder();
            foreach (char c in text)// Перебираем каждый символ входного текста.
            {
                int index = NormalAlphabet.IndexOf(c);// Находим индекс текущего символа в NormalAlphabet.
                if (index >= 0)
                {
                    encryptedText.Append(EncryptedAlphabet[index]);// Заменяем его символом из EncryptedAlphabet с тем же индексом.
                }
                else
                {
                    encryptedText.Append(c);// Если символ не найден в алфавите, оставляем его без изменений
                }
            }
            return encryptedText.ToString();
        }

        private string Decrypt(string text)
        {
            StringBuilder decryptedText = new StringBuilder();
            foreach (char c in text)
            {
                int index = EncryptedAlphabet.IndexOf(c); // Находим индекс в зашифрованном алфавите
                if (index >= 0)
                {
                    decryptedText.Append(NormalAlphabet[index]); // Берем символ из обычного алфавита с тем же индексом
                }
                else
                {
                    decryptedText.Append(c); // Если символа нет в зашифрованном алфавите, оставляем его как есть
                }
            }
            return decryptedText.ToString();
        }
    }
}
