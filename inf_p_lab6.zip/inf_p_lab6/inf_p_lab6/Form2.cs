﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inf_p_lab6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        // Метод для загрузки и воспроизведения видео
        public void PlayVideo(string videoPath)
        {
            axWindowsMediaPlayer1.URL = videoPath; // Указываем путь к видео
            axWindowsMediaPlayer1.Ctlcontrols.play(); // Начинаем воспроизведение

            // Подписываемся на событие завершения воспроизведения
            axWindowsMediaPlayer1.PlayStateChange += AxWindowsMediaPlayer1_PlayStateChange;
        }

        // Обработчик события изменения состояния воспроизведения
        private void AxWindowsMediaPlayer1_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            // Если воспроизведение завершено (состояние 8)
            if (e.newState == 8)
            {
                // Закрываем форму
                this.Close();
                Application.Exit(); // Завершаем программу
            }
        }
    }
}
