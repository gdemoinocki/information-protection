﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Management;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Policy;

namespace inf_p_lab6
{
    public partial class Form1 : Form
    {
        private string savedHash; // Сохраненный хеш для проверки

        public Form1()
        {
            InitializeComponent();
            CheckAuthorization(); // Проверяем авторизацию при запуске
        }

        // Метод для проверки авторизации
        private void CheckAuthorization()
        {
            savedHash = Properties.Settings.Default.SavedHash; // Получаем сохраненный хеш

            if (string.IsNullOrEmpty(savedHash))// Если хеш не сохранен, сохраняем текущий хеш
            {
                savedHash = GenerateHardwareHash();
                Properties.Settings.Default.SavedHash = savedHash;
                Properties.Settings.Default.Save();
                MessageBox.Show("Программа успешно зарегистрирована на этом компьютере.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Если хеш сохранен, проверяем ег
                string currentHash = GenerateHardwareHash();
                if (currentHash != savedHash)
                {
                    MessageBox.Show("Программа используется на неавторизованном компьютере!\nВас ждёт сюрприз :)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ShowWarningVideo();// Показываем видео
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Программа авторизована.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    label2.Text += savedHash.ToString();
                    string hardwareInfo = GetMotherboardSerialNumber();
                    label3.Text += hardwareInfo;
                }
            }
        }

        // Метод для отображения видео
        private void ShowWarningVideo()
        {
            Form2 warningForm = new Form2();
            warningForm.PlayVideo("C:\\Users\\4769003\\source\\repos\\inf_p_lab6\\video2.mp4"); // Укажите путь к видео
            warningForm.ShowDialog(); // Показываем форму с видео (после закрытия формы программа завершится)
        }

        // Метод для генерации хеша на основе информации о материнской плате
        private string GenerateHardwareHash()
        {
            string hardwareInfo = GetMotherboardSerialNumber(); // Получаем серийный номер материнской платы
            return MD5(hardwareInfo); // Хешируем информацию
        }

        // Метод для получения серийного номера материнской платы
        private string GetMotherboardSerialNumber()
        {
            string serialNumber = string.Empty;

            // Используем WMI для получения серийного номера материнской платы
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");
            foreach (ManagementObject mo in searcher.Get())
            {
                serialNumber = mo["SerialNumber"]?.ToString();
                break; // Берем только первый результат
            }
            return serialNumber;
        }

        // Метод для вычисления MD5 хеша
        private string MD5(string message)
        {
            // 1. Добавляем биты дополнения (Padding) MD5 работает с блоками по 512 бит (64 байта).  Необходимо
            // дополнить сообщение, чтобы его длина была кратна 512 битам.

            byte[] bytes = Encoding.UTF8.GetBytes(message); // Преобразуем сообщение в массив байтов в кодировке UTF-8
            int originalLengthBits = bytes.Length * 8; // Исходная длина сообщения в битах
            // Расчитываем длину дополнения.  Должно быть достаточно места для бита '1', нулей и 64 битов для длины.
            int paddingLength = 64 - ((bytes.Length + 1 + 8) % 64); // Длина дополнения, чтобы общая длина была кратна 64 байтам
            if (paddingLength < 0) paddingLength += 64; // Обработка отрицательных paddingLength

            byte[] paddedBytes = new byte[bytes.Length + 1 + paddingLength + 8]; // Создаем массив с дополненными байтами
            Array.Copy(bytes, 0, paddedBytes, 0, bytes.Length); // Копируем исходное сообщение
            paddedBytes[bytes.Length] = 0x80; // Добавляем бит '1' (за которым следуют нули) - 0x80 это 10000000 в двоичной системе

            // 2. Добавляем длину исходного сообщения
            // В конце дополненного сообщения добавляем 64 бита, представляющих длину исходного сообщения в битах.

            byte[] lengthBytes = BitConverter.GetBytes((long)originalLengthBits); // Преобразуем длину в массив байтов
            if (BitConverter.IsLittleEndian) Array.Reverse(lengthBytes); //MD5 требует порядок байтов big-endian.
            Array.Copy(lengthBytes, 0, paddedBytes, bytes.Length + 1 + paddingLength, 8); // Копируем байты длины в конец дополненного сообщения

            // 3. Обрабатываем сообщение блоками по 512 бит (64 байта)
            // MD5 обрабатывает сообщение блоками по 64 байта.

            // Инициализируем начальные значения хеша (эти значения определены в стандарте MD5)
            uint a = 0x67452301;
            uint b = 0xEFCDAB89;
            uint c = 0x98BADCFE;
            uint d = 0x10325476;

            for (int i = 0; i < paddedBytes.Length; i += 64)
            {
                // Разбиваем блок на шестнадцать 32-битных слов M[i], 0 <= i <= 15
                uint[] M = new uint[16];
                for (int j = 0; j < 16; j++)
                {
                    M[j] = BitConverter.ToUInt32(paddedBytes, i + j * 4); // Преобразуем 4 байта в 32-битное слово
                    if (BitConverter.IsLittleEndian) M[j] = ReverseBytes(M[j]); //Преобразуем в big-endian при необходимости
                }
                // Инициализируем хеш-значение для этого блока
                uint A = a, B = b, C = c, D = d;

                // Main Round (упрощенно, без раундовых констант и значений сдвига)
                // В настоящей реализации MD5 здесь будет 64 раунда сложных операций.  Этот цикл упрощен для иллюстрации.
                for (int j = 0; j < 64; j++)
                {
                    uint F = 0;
                    if (j < 16)
                        F = (B & C) | ((~B) & D);
                    else if (j < 32)
                        F = (D & B) | ((~D) & C);
                    else if (j < 48)
                        F = B ^ C ^ D;
                    else
                        F = C ^ (B | (~D));

                    uint temp = D;
                    D = C;
                    C = B;
                    B = B + Leftrotate((A + F + M[j % 16]), j % 32); //Поворачивать влево для всех раундов
                    A = temp;

                    //Смешивание исходных значений
                    A = B;
                    B = C;
                    C = D;
                    D = F;
                }

                // Добавляем хеш этого блока к промежуточному результату
                a += A;
                b += B;
                c += C;
                d += D;
            }

            // 4. Формируем окончательное значение хеша (128-битный дайджест)
            byte[] digest = new byte[16];
            Array.Copy(BitConverter.GetBytes(a), 0, digest, 0, 4); // Копируем первые 4 байта (a)
            Array.Copy(BitConverter.GetBytes(b), 0, digest, 4, 4); // Копируем следующие 4 байта (b)
            Array.Copy(BitConverter.GetBytes(c), 0, digest, 8, 4); // Копируем следующие 4 байта (c)
            Array.Copy(BitConverter.GetBytes(d), 0, digest, 12, 4); // Копируем последние 4 байта (d)
            // Корректировка порядка байтов для little-endian систем
            if (BitConverter.IsLittleEndian)
            {
                for (int k = 0; k < 4; ++k)
                {
                    Array.Reverse(digest, k * 4, 4);// Реверсируем порядок байтов в каждом 32-битном слове
                }
            }
            // Преобразование хеша в шестнадцатеричную строку
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < digest.Length; i++)
            {
                sb.Append(digest[i].ToString("x2")); // Преобразуем каждый байт в шестнадцатеричную строку
            }
            return sb.ToString(); // Возвращаем шестнадцатеричное представление хеша
        }
        // Функция для реверсирования порядка байтов в 32-битном слове (для big-endian)
        static uint ReverseBytes(uint value)
        {
            return (value & 0x000000FFU) << 24 | (value & 0x0000FF00U) << 8 |
                   (value & 0x00FF0000U) >> 8 | (value & 0xFF000000U) >> 24;
        }
        // Функция циклического сдвига влево
        static uint Leftrotate(uint x, int c)
        {
            return (x << c) | (x >> (32 - c));
        }
        // Обработчик события для кнопки "Сбросить хеш"
        private void btnResetHash_Click(object sender, EventArgs e)
        {
            // Сбрасываем сохраненный хеш
            Properties.Settings.Default.SavedHash = string.Empty;
            Properties.Settings.Default.Save();

            // Сообщаем пользователю
            MessageBox.Show("Хеш сброшен. Программа будет перезапущена для повторной регистрации.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Перезапускаем программу
            Application.Restart();
        }

    }
}
