﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;
using System.Security.Cryptography;

namespace inf_p_lab4
{
    public partial class Form1 : Form
    {
        private BigInteger p, q, n, phi, e, d;

        public Form1()
        {
            InitializeComponent();
        }
        //Генерировать ключи
        private void btnGenerateKeys_Click(object sender, EventArgs e)
        {
            GenerateKeys();// Вызываем метод для генерации ключей RSA
        }
        //Зашифровать
        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            txtCipherText.Text = Encrypt(txtPlainText.Text);// Шифруем текст из и отображаем результат
        }
        //Дешифровать
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            txtDecryptedText.Text = Decrypt(txtCipherText.Text);// Дешифруем текст и отображаем результат
        }
        //Метод для генерации ключей RSA
        private void GenerateKeys()
        {
            // Выбираем два больших простых числа p и q
            p = GeneratePrimeNumber(256); //длинна 256 bits
            q = GeneratePrimeNumber(256); //длинна 256 bits
            // Вычисляем n = p * q
            n = p * q;
            // Вычисляем функцию Эйлера phi(n) = (p-1) * (q-1)
            phi = (p - 1) * (q - 1);
            // Выбираем открытый ключ e (1 < e < phi(n), НОД(e, phi(n)) = 1)
            e = GeneratePublicKey(phi);
            // Вычисляем секретный ключ d (d * e ≡ 1 (mod phi(n))), d - мультипликативное обратное e по модулю phi
            d = ModInverse(e, phi);

            MessageBox.Show("Ключи сгенерированы!");
            
            MessageBox.Show($"p: {p}\nq: {q}\nn: {n}\ne: {e}\nd: {d}");//Отображаем ключи
        }
        // Метод для шифрования текста
        private string Encrypt(string plainText)
        {
            // Проверяем, что текст введен и ключи сгенерированы
            if (string.IsNullOrEmpty(plainText) || n == 0 || e == 0)
            {
                MessageBox.Show("Сначала сгенерируйте ключи и введите текст.");
                return "";
            }

            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);// Преобразуем текст в байты (UTF-8)
            BigInteger message = new BigInteger(plainTextBytes);// Преобразуем байты в BigInteger

            // Шифрование: ciphertext = message^e mod n
            BigInteger cipher = BigInteger.ModPow(message, e, n);// Вычисляем зашифрованное сообщение

            return cipher.ToString();// Возвращаем зашифрованное сообщение в виде строки
        }
        // Метод для дешифрования текста
        private string Decrypt(string cipherText)
        {
            // Проверяем, что зашифрованный текст введен и ключи сгенерированы
            if (string.IsNullOrEmpty(cipherText) || n == 0 || d == 0)
            {
                MessageBox.Show("Сначала сгенерируйте ключи и зашифруйте текст.");
                return "";
            }

            BigInteger cipher = BigInteger.Parse(cipherText);// Преобразуем строку зашифрованного сообщения в BigInteger

            // Дешифрование: message = ciphertext^d mod n
            BigInteger message = BigInteger.ModPow(cipher, d, n);// Вычисляем расшифрованное сообщение

            byte[] messageBytes = message.ToByteArray();// Преобразуем BigInteger в байты
            return Encoding.UTF8.GetString(messageBytes);// Преобразуем байты в текст (UTF-8) и возвращаем результат
        }

        // Генерация случайного простого числа
        private BigInteger GeneratePrimeNumber(int bits)
        {
            while (true)// Бесконечный цикл, пока не будет найдено простое число
            {
                BigInteger num = GenerateRandomBigInteger(bits);// Генерируем случайное BigInteger
                if (IsProbablyPrime(num))// Проверяем, является ли число простым
                {
                    return num;
                }
            }
        }

        // Генерация случайного BigInteger
        private BigInteger GenerateRandomBigInteger(int bits)
        {
            RandomNumberGenerator rng = RandomNumberGenerator.Create();// Создаем экземпляр криптографически стойкого генератора случайных чисел
            byte[] bytes = new byte[bits / 8];// Выделяем массив байтов нужного размера
            rng.GetBytes(bytes);// Заполняем массив случайными байтами
            return new BigInteger(bytes);// Создаем BigInteger из байтов
        }


        // Проверка на простоту (вероятностный тест Миллера-Рабина)
        private bool IsProbablyPrime(BigInteger n, int k = 40) // k - параметр точности (чем больше, тем точнее, но медленнее)
        {
            if (n <= 1) return false;// Числа меньше или равные 1 не являются простыми
            if (n == 2 || n == 3) return true;// 2 и 3 - простые числа
            if (n % 2 == 0) return false;// Четные числа, кроме 2, не являются простыми

            BigInteger d = n - 1;
            BigInteger s = 0;// s - количество нулей в двоичном представлении d

            while (d % 2 == 0)
            {
                d /= 2;
                s++;
            }

            RandomNumberGenerator rng = RandomNumberGenerator.Create();// Создаем экземпляр криптографически стойкого генератора случайных чисел
            byte[] bytes = new byte[n.ToByteArray().LongLength];// Выделяем массив байтов нужного размера
            BigInteger a;// a - случайное число в диапазоне [2, n-2]

            for (int i = 0; i < k; i++)
            {
                do
                {
                    rng.GetBytes(bytes);// Генерируем случайные байты
                    a = new BigInteger(bytes);// Преобразуем байты в BigInteger
                } while (a < 2 || a >= n - 2);// Повторяем, пока a не попадет в нужный диапазон

                BigInteger x = BigInteger.ModPow(a, d, n);

                if (x == 1 || x == n - 1) // Если x = 1 или x = n-1, то число, вероятно, простое
                    continue;

                for (BigInteger r = 1; r < s; r++)
                {
                    x = BigInteger.ModPow(x, 2, n);// Если x = n-1, то число, вероятно, простое
                    if (x == n - 1)
                        break;
                }

                if (x != n - 1) // Если x != n-1, то число составное
                    return false;
            }

            return true;
        }


        // Генерация открытого ключа e (1 < e < phi(n), НОД(e, phi(n)) = 1)
        private BigInteger GeneratePublicKey(BigInteger phi)
        {
            BigInteger e = 65537; // Обычно используется это простое число Ферма (2^16 + 1)

            if (GreatestCommonDivisor(e, phi) == 1)
                return e;// Если e и phi взаимно просты, то возвращаем e

            //Если 65537 не взаимно простое, генерируем случайное число
            Random rand = new Random();
            while (true)// Бесконечный цикл, пока не будет найдено подходящее e
            {
                BigInteger candidate = rand.Next(1, (int)(phi - 1)); //Генерируем случайное число в диапазоне [1, phi-1]
                if (GreatestCommonDivisor(candidate, phi) == 1)// Проверяем, что НОД(candidate, phi) = 1
                    return candidate;// Если candidate и phi взаимно просты, то возвращаем candidate
            }
        }

        // Вычисление наибольшего общего делителя (НОД) с помощью алгоритма Евклида
        private BigInteger GreatestCommonDivisor(BigInteger a, BigInteger b)
        {
            while (b != 0)
            {
                BigInteger temp = b;// Сохраняем b во временной переменной
                b = a % b;
                a = temp;
            }
            return a;
        }

        // Вычисление мультипликативного обратного по модулю (d * e ≡ 1 (mod phi(n))) с использованием расширенного алгоритма Евклида
        private BigInteger ModInverse(BigInteger a, BigInteger m)
        {
            BigInteger m0 = m;
            BigInteger y = 0, x = 1;

            if (m == 1)// Если m = 1, то мультипликативного обратного не существует
                return 0;

            while (a > 1)
            {
                // q is quotient
                BigInteger q = a / m;
                BigInteger t = m;

                // теперь m - это остаток, процесс такой же, как в алгоритме Евклида
                m = a % m;
                a = t;// a = m (предыдущее значение m)
                t = y;// Сохраняем y во временной переменной

                // Обновляем y и x
                y = x - q * y;
                x = t;
            }

            // Делаем x положительным
            if (x < 0)
                x += m0;

            return x;
        }

    }
}
